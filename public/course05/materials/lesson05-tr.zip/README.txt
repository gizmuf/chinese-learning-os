Chinese OS - Ders 05 / 26 Ekim 2026

Hanzi çalışma defteri: çizgi sırası, üzerinden geçme ve bellekten yazma.
Çalışma kılavuzu: kelimeler, pinyin, Türkçe anlamlar, dil bilgisi ve alıştırmalar.
Kısa başvuru: tek sayfalık cümle özeti.

Çevrimiçi: https://chinese-os-study.gizmuf.chatgpt.site/?course=intensive&lesson=5
