Chinese OS - Lesson 05 / 26 October 2026

Study guide: vocabulary, pinyin, meanings, grammar, comparisons and reading checks.
Hanzi workbook: cumulative strokes, tracing and blank writing practice.
Quick reference: one-page sentence reminder.

In the app: Course > Lesson 05. Select one topic, study, build an expression, then try reading/listening without pinyin. Return for scheduled reviews.
The EN/FR/RU files share the same lesson content and pagination.
